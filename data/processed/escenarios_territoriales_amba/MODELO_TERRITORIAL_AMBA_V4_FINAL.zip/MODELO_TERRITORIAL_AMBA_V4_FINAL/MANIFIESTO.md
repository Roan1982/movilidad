# MANIFIESTO — MODELO TERRITORIAL AMBA V4.1

## Identificación

- Proceso: 46
- Versión: V4.1
- Estado: FINAL
- Dictamen: GO
- Generado: 2026-08-21 17:50:40

## Archivos

| Archivo | Tamaño bytes | SHA-256 |
|---|---:|---|
| 01_modelo/control_43_paquete_ejecutivo_amba_v4_1.csv | 606 | 3ae2ce2b4a9a20db981c4792c4ae765347491d2b0fd281c11811dcd63d880cf0 |
| 01_modelo/control_paquete_ejecutivo_amba_v4_1.csv | 665 | 16917aa8042a23d0e73c2dc88dc8b53f63b82a35f8fadfb1d9f585e03aa999ea |
| 01_modelo/hashes_43_paquete_ejecutivo_amba_v4_1.csv | 1807 | c22400a33ac87ac77586e6d21bb4702a519093545e7d9128545afab838ac25b6 |
| 01_modelo/hashes_paquete_ejecutivo_amba_v4_1.csv | 966 | 48d90e65f0e199d98e9f99a6622c8beb93892b9034ca362590b570122be5bda3 |
| 01_modelo/indicadores_globales_amba_v4.csv | 1476 | 172ea570d14d77f806bc8395f8553f159056524d343b7c4b5c5fd0f80acea27e |
| 01_modelo/manifiesto_43_paquete_ejecutivo_amba_v4_1.csv | 1616 | df35341eabc0b7427b2347e409eea3901574207c5a0d232c686ebb1bb6332d5c |
| 01_modelo/modelo_maestro_escenarios_v4.csv | 4761 | 87eb0e6978c263e2cd379d2d83f92f60d4cb3f80c14471cabb303ce921a6d7a8 |
| 01_modelo/modelo_maestro_proyectos_v4.csv | 316321 | d6a24cddd8ed1a71bf324c252494cf7088b0d65dc4729128394b26bc63f18035 |
| 01_modelo/productos_referencia_43_amba_v4_1.csv | 3280 | 498e6ab2ce78ad1373cb997ac1c46882a08d972e3482caeff60431aa0565a67c |
| 01_modelo/productos_referencia_amba_v4_1.csv | 1263 | bc6e9093f310f82485cf4ff7aedb84fa780858ea56c5c8da04b113ef5639e0b5 |
| 01_modelo/ranking_final_escenarios_v4.csv | 1462 | 1a5060caa9d319bef9d05510c021f2e16605ef5eb51b20a1a1ee9f93c02e9a1b |
| 01_modelo/ranking_final_proyectos_v4.csv | 27652 | 2cc9d6cba916082669e6046c2ed0d9f9d2b622779594596a46fdfc9406634859 |
| 04_datos/resultado_final_43_paquete_ejecutivo_amba_v4_1.json | 735 | 698205756881c24daedb0dc09586bee3af88bd8718030c93c881b6abc4e50f72 |
| 04_datos/resumen_43_paquete_ejecutivo_amba_v4_1.json | 2991 | bdbe28aefce8f23614cf9370c9a0ab1d7cde6e344e068a799d5de9ce0357c8a4 |
| 05_auditoria/auditoria_44_paquete_final_amba_v4.csv | 1605 | 08874c30aa3397b9a4c92e4341f53319f54dbcc2d15c4fb34aa329356c144ec5 |
| 05_auditoria/auditoria_45_cierre_amba_v4.csv | 2411 | 03124a91463f0a103308a278552374e17464cf2aa4abd5cfc4e9be238f8dcbd9 |
| 05_auditoria/hashes_45_cierre_amba_v4.csv | 1673 | 6bd473a06fbcc94e458a7228d286c22419edb5583598b1b1846374e3e9b8cf4f |
| 05_auditoria/informe_45_cierre_amba_v4.md | 3472 | e4ccc7f8dcf639d51af4abea6dc55ab298cf15cf6cf7379dcebb66a099a480db |
| 05_auditoria/inventario_45_cierre_amba_v4.csv | 2045 | 210f0eac7899587a20d9f0c791069da61d0ff661433f768138eac7af49a5c941 |
| 05_auditoria/resumen_45_cierre_amba_v4.json | 1451 | e7a95afe90c37849559f62a6c90f4afa9e585b95033cd0eb83d620e141c32e8b |
| 06_metadatos/MANIFIESTO_SHA256.csv | 2588 | a688aebbe615b01f0aee3788ff3174e9de29d919cb94b490b177e09cfb6c81b7 |
| 06_metadatos/metadata.json | 291 | e7ea8d0be308cb4112cfe4224038a604680737ece3385a4d1b9c7d2da684ce0f |
| 06_metadatos/version.txt | 68 | 7181ec0835c074e17c3dd048e8a9fbcb4051facd3d7e3cdfaeb7ae0c7b95e25d |
| README.md | 1542 | b4a7a667c70c57b84663d448d717a30e731fdcf680aa7d5f76994dfdad22b579 |

## Auditorías

- Proceso 42: GO
- Proceso 43: GO
- Proceso 44: GO
- Proceso 45: GO

## Declaración

Este manifiesto identifica los archivos incluidos en el paquete definitivo y sus correspondientes hashes SHA-256.

**DICTAMEN FINAL: GO**
